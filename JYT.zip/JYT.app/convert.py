from glob import glob
from os import system
import re
import subprocess
import shlex

lib_re = re.compile("/Applications\/.*?\.app\/lib\/(.*\.dylib)")

NEW_PATH = "/Applications/JYT.app/Contents/"

for dylib in glob("Contents/Resources/lib/*.dylib"):
    raw = subprocess.Popen(shlex.split("otool -L "+dylib), stdout=subprocess.PIPE).communicate()[0]
    libs = lib_re.findall(raw)
    
    for lib in libs:
        frm = "/Applications/PPCMC.app/lib/" + lib
        to = NEW_PATH+"Resources/lib/"+lib
        
        command = "install_name_tool -change %s %s %s" % (frm, to, dylib)
        print command
        system(command)
        
        #command = "install_name_tool -id %s %s" % (to, dylib)
        #print command
        #system(command)

        
for exe in glob("Contents/Resources/bin/*"):
    raw = subprocess.Popen(shlex.split("otool -L "+exe), stdout=subprocess.PIPE).communicate()[0]
    libs = lib_re.findall(raw)
    
    for lib in libs:
        frm = "/Applications/PPCMC.app/lib/" + lib
        to = NEW_PATH+"Resources/lib/"+lib
        
        command = "install_name_tool -change %s %s %s" % (frm, to, exe)
        print command
        system(command)

